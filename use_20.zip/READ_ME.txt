Computer: use_20
1. Keep this package private. It contains one computer-specific key.
2. Extract the ZIP on this computer only.
3. Open Windows PowerShell as Administrator in the extracted folder.
4. Run: powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\install.ps1
5. In https://167.86.96.175, enable use_20 under Data collection > Hosts.
   Alternative on the server: python3 /root/monitoring/enroll.py use_20 --enable
6. Check Latest data after two minutes. Do not reuse this enrollment on another computer.
The installer downloads and verifies the official Zabbix agent. It does not alter
AnyDesk, UltraViewer, Tailscale, or the original monitoring-agent scheduled task.
