#Requires -RunAsAdministrator
param([string] $EnrollmentFile = (Join-Path $PSScriptRoot 'enrollment.json'))
$ErrorActionPreference = 'Stop'
$enrollment = Get-Content -LiteralPath $EnrollmentFile -Raw | ConvertFrom-Json
if ($enrollment.Hostname -notmatch '^win-[a-f0-9]{32}$' -or
    $enrollment.PskIdentity -notmatch '^win-[a-f0-9]{32}$' -or
    $enrollment.Psk -notmatch '^[a-f0-9]{64}$' -or
    $enrollment.Server -notmatch '^\d{1,3}(\.\d{1,3}){3}$' -or
    $enrollment.AgentPackageFormat -ne 'msi' -or
    $enrollment.AgentVersion -notmatch '^7\.0\.\d+$' -or
    $enrollment.AgentArchiveSha256 -notmatch '^[a-f0-9]{64}$') {
    throw 'Invalid enrollment data. Obtain a new package from the server.'
}
$installRoot = Join-Path $env:ProgramFiles 'ComputerMonitoring'
$stateRoot = Join-Path $env:ProgramData 'ComputerMonitoring'
$configuration = Join-Path $stateRoot 'zabbix_agent2.conf'
$binary = Join-Path $installRoot 'zabbix_agent2.exe'
# Read the service configuration directly so installation does not depend on CIM/WMI.
$serviceRegistryPath = 'HKLM:\SYSTEM\CurrentControlSet\Services\Zabbix Agent 2'
$existingService = if (Test-Path -LiteralPath $serviceRegistryPath) {
    Get-ItemProperty -LiteralPath $serviceRegistryPath -ErrorAction Stop
}
$expectedImage = '^\s*(?:"' + [regex]::Escape($binary) + '"|' + [regex]::Escape($binary) + ')(?:\s|$)'
if ($existingService -and [Environment]::ExpandEnvironmentVariables([string]$existingService.ImagePath) -notmatch $expectedImage) {
    throw 'A separately managed Zabbix Agent 2 already exists. Review it before installing.'
}
if ($existingService -and (Test-Path -LiteralPath $configuration)) {
    $existingHostname = Select-String -LiteralPath $configuration -Pattern '^Hostname=(.+)$'
    if ($existingHostname -and $existingHostname.Matches[0].Groups[1].Value -ne $enrollment.Hostname) {
        throw 'This computer is enrolled under another identity. Use its original enrollment package.'
    }
}
$downloadRoot = Join-Path $env:TEMP ('monitoring-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $downloadRoot -Force | Out-Null
$version = $enrollment.AgentVersion
$url = "https://cdn.zabbix.com/zabbix/binaries/stable/7.0/$version/zabbix_agent2-$version-windows-amd64-openssl.msi"
$archive = Join-Path $downloadRoot 'agent.msi'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Invoke-WebRequest -Uri $url -OutFile $archive -UseBasicParsing
if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $enrollment.AgentArchiveSha256) {
    throw 'The agent download did not match the enrollment checksum.'
}
$signature = Get-AuthenticodeSignature -LiteralPath $archive
if ($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch 'Zabbix') {
    throw 'The agent package does not have a valid Zabbix publisher signature.'
}
$extractRoot = Join-Path $downloadRoot 'agent'
$extract = Start-Process -FilePath msiexec.exe -ArgumentList @('/a', "`"$archive`"", '/qn', '/norestart', "TARGETDIR=`"$extractRoot`"") -WindowStyle Hidden -Wait -PassThru
if ($extract.ExitCode -ne 0) { throw "Agent package extraction failed with code $($extract.ExitCode)." }
$downloadedBinary = @(Get-ChildItem -LiteralPath (Join-Path $downloadRoot 'agent') -Recurse -Filter zabbix_agent2.exe)
if ($downloadedBinary.Count -ne 1) { throw 'Expected exactly one Zabbix Agent 2 binary in the archive.' }
if ($existingService) { Stop-Service -Name 'Zabbix Agent 2' -ErrorAction Stop }
New-Item -ItemType Directory -Path $installRoot,$stateRoot -Force | Out-Null
& icacls.exe $stateRoot /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Could not protect the monitoring data directory.' }
Copy-Item -LiteralPath $downloadedBinary[0].FullName -Destination $binary -Force
Copy-Item -Path (Join-Path $downloadedBinary[0].DirectoryName '*.dll') -Destination $installRoot -Force -ErrorAction SilentlyContinue
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'collect.ps1') -Destination (Join-Path $installRoot 'collect.ps1') -Force
[IO.File]::WriteAllText((Join-Path $stateRoot 'agent.psk'), $enrollment.Psk)
$config = @"
Hostname=$($enrollment.Hostname)
ServerActive=$($enrollment.Server):10051
ListenIP=127.0.0.1
TLSConnect=psk
TLSAccept=psk
TLSPSKIdentity=$($enrollment.PskIdentity)
TLSPSKFile=$stateRoot\agent.psk
LogFile=$stateRoot\agent.log
LogFileSize=10
Timeout=20
RefreshActiveChecks=60
HeartbeatFrequency=60
EnablePersistentBuffer=1
PersistentBufferPeriod=24h
PersistentBufferFile=$stateRoot\buffer.db
DenyKey=system.run[*]
UserParameter=monitoring.snapshot,powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "$installRoot\collect.ps1" -Mode Snapshot
UserParameter=monitoring.public_ip,powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "$installRoot\collect.ps1" -Mode PublicIp
"@
[IO.File]::WriteAllText($configuration, $config + [Environment]::NewLine)
& $binary --config $configuration --test agent.ping | Out-Host
if ($LASTEXITCODE -ne 0) { throw 'Agent configuration validation failed.' }
if (-not $existingService) {
    & $binary --config $configuration --install
    if ($LASTEXITCODE -ne 0) { throw 'Windows service installation failed.' }
}
Set-Service -Name 'Zabbix Agent 2' -StartupType Automatic
& sc.exe failure 'Zabbix Agent 2' reset= 86400 actions= restart/60000/restart/60000/restart/60000 | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Could not configure Windows service recovery.' }
Start-Service -Name 'Zabbix Agent 2'
Write-Host "Installed $($enrollment.DisplayName). Enable this host in the Zabbix dashboard to begin monitoring."
Write-Host 'The enrollment package contains this computer''s private key. Keep it private.'
