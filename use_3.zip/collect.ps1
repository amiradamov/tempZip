param(
    [ValidateSet('Snapshot', 'PublicIp')] [string] $Mode = 'Snapshot',
    [string] $StateDirectory = "$env:ProgramData\ComputerMonitoring"
)
$ErrorActionPreference = 'Stop'

function Get-MonitoringSnapshot {
    $processes = @(Get-Process -ErrorAction SilentlyContinue)
    $names = @($processes | ForEach-Object { $_.ProcessName.ToLowerInvariant() })
    $tailscaleService = Get-Service -Name Tailscale -ErrorAction SilentlyContinue
    $tailscaleAddress = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
        Where-Object { $_.InterfaceAlias -match 'Tailscale' } |
        Select-Object -ExpandProperty IPAddress)
    $wireguardAddress = @()
    try {
        $wireguardAddress = @([Net.NetworkInformation.NetworkInterface]::GetAllNetworkInterfaces() |
            Where-Object { $_.Description -match 'WireGuard' } |
            ForEach-Object { $_.GetIPProperties().UnicastAddresses } |
            Where-Object { $_.Address.AddressFamily -eq [Net.Sockets.AddressFamily]::InterNetwork } |
            ForEach-Object { $_.Address.ToString() })
    } catch { }
    $os = Get-CimInstance Win32_OperatingSystem
    $cpu = Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor -Filter "Name='_Total'"
    $memoryPercent = 100 * (1 - [double]$os.FreePhysicalMemory / [double]$os.TotalVisibleMemorySize)
    $top = @()
    if ([double]$cpu.PercentProcessorTime -ge 90 -or $memoryPercent -ge 90) {
        $top = @($processes | Sort-Object WorkingSet64 -Descending | Select-Object -First 5 |
            ForEach-Object { @{ name = $_.ProcessName; pid = $_.Id; memory_bytes = $_.WorkingSet64 } })
    }
    return @{
        timestamp = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
        anydesk_running = [int]([bool](@($names | Where-Object { $_ -in @('anydesk', 'anydeskmsi') }).Count))
        ultraviewer_running = [int]([bool](@($names | Where-Object { $_ -in @('ultraviewer', 'ultraviewer_desktop', 'ultraviewer_service') }).Count))
        tailscale_running = [int]([bool]($tailscaleService -and $tailscaleService.Status -eq 'Running'))
        tailscale_ip = ($tailscaleAddress -join ', ')
        wireguard_ip = if ($wireguardAddress.Count) { $wireguardAddress -join ', ' } else { 'Not detected' }
        top_processes = $top
    }
}

function Get-PublicIpObservation {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $ip = $null
    foreach ($source in @('https://api4.ipify.org', 'https://ifconfig.me/ip')) {
        try {
            $candidate = ([string](Invoke-RestMethod -Uri $source -TimeoutSec 7)).Trim()
            $address = $null
            if ([Net.IPAddress]::TryParse($candidate, [ref]$address) -and
                $address.AddressFamily -eq [Net.Sockets.AddressFamily]::InterNetwork) {
                $ip = $address.ToString()
                break
            }
        } catch { continue }
    }
    if (-not $ip) { throw 'Public IPv4 lookup failed at every configured source' }
    $statePath = Join-Path $StateDirectory 'public-ip.json'
    $firstSeen = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    if (Test-Path -LiteralPath $statePath) {
        try {
            $previous = Get-Content -LiteralPath $statePath -Raw | ConvertFrom-Json
            if ($previous.ip -eq $ip -and [long]$previous.first_seen -gt 0) {
                $firstSeen = [long]$previous.first_seen
            }
        } catch { } # A corrupt cache must not suppress current network observations.
    }
    $observation = @{ ip = $ip; first_seen = $firstSeen }
    New-Item -ItemType Directory -Path $StateDirectory -Force | Out-Null
    $temporaryPath = Join-Path $StateDirectory ('public-ip-' + [guid]::NewGuid().ToString('N') + '.tmp')
    [IO.File]::WriteAllText($temporaryPath, ($observation | ConvertTo-Json -Compress))
    Move-Item -LiteralPath $temporaryPath -Destination $statePath -Force
    return $observation
}

if ($Mode -eq 'PublicIp') { Get-PublicIpObservation | ConvertTo-Json -Depth 5 -Compress }
else { Get-MonitoringSnapshot | ConvertTo-Json -Depth 5 -Compress }
